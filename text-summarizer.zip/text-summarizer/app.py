from flask import Flask, render_template, request, stream_with_context
import requests
from bs4 import BeautifulSoup
from summarizer import Summarizer
from sklearn.cluster import KMeans
import re
from nltk.tokenize import sent_tokenize

app = Flask(__name__)

def remove_loader():
    return f'<script>document.getElementsByClassName("loader")[0].classList.remove("loader")</script>'

# Custom filters for counting sentences, words, and characters
@app.template_filter('count_sentences')
def count_sentences(text):
    return len(sent_tokenize(text))

@app.template_filter('count_words')
def count_words(text):
    return len(re.findall(r'\b\w+\b', text))

@app.template_filter('count_characters')
def count_characters(text):
    return len(text)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/process_form', methods=['POST'])
def process_form():
    url = request.form['url']

    # Send a GET request to the Wikipedia page
    response = requests.get(url)

    # Parse the HTML content using BeautifulSoup
    soup = BeautifulSoup(response.content, "html.parser")

    # Find and extract specific elements from the page
    title = soup.find(id="firstHeading").text
    paragraphs = soup.select("#mw-content-text p")
    
    # Initialize paragraphText
    paragraphText = ""

    # Calculate the total number of paragraphs for progress calculation
    total_paragraphs = len(paragraphs)
    processed_paragraphs = 0

    def generate_progress_scripts():
        nonlocal paragraphText, processed_paragraphs

        if total_paragraphs == 0:
            # Handle the case where there are no paragraphs
            return
        
        yield '<style>'
        yield 'body{min-height:100vh; display:flex; justify-content: center; align-items: center;}'
        yield '.loader{border: 8px solid #f3f3f3; border-top: 8px solid #3498db; border-radius: 50%; width: 50px; height: 50px; animation: spin 1s linear infinite; margin: 20px auto;}'
        yield '@keyframes spin {0%{ transform: rotate(0deg); } 100% { transform: rotate(360deg);}}'
        yield '</style>'
       
        yield '<div class="loader"></div>'
        


        for idx, paragraph in enumerate(paragraphs, start=1):
            paragraphText += paragraph.text + "\n"
        
        # Apply text summarization using BERT Extractive Summarizer
        summarizer = Summarizer()
        summarized_text = summarizer(paragraphText)

        # Explicitly set the value of n_init to suppress the warning
        kmeans = KMeans(n_clusters=3, n_init=10)  # You can replace 10 with another appropriate value

        data = {
            "title": title,
            "original_paragraphs": paragraphText,
            "summarized_text": summarized_text
        }

        # Update progress bar to 100% after processing is complete
        yield remove_loader()

        # Render the response template
        yield render_template('response.html', data=data)

    return stream_with_context(generate_progress_scripts())

if __name__ == '__main__':
    app.run()
